package model;

//jack(sota), knight(caballo) y king(rey)
public enum CardFace {
    JACK,
    KNIGHT,
    KING
}
