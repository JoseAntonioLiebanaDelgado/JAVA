package model;

public enum CardSuit {
    GOLD,
    SWORDS,
    CUPS,
    CLUBS
}
